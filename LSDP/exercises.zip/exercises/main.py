def main():
    print("Hello from exercises!")


if __name__ == "__main__":
    main()
